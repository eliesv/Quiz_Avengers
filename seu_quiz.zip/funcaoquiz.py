from flask import request
def multiplaescolha(pergunta):
	lista=[]
	x = request.form[pergunta]
	if pergunta=="vai funcionar?": 
		if x=="0":
			lista=['sim']
		if x=="1":
			lista=['nao']
	if pergunta=="qual seu nome": 
		if x=="0":
			lista=['sim']
		if x=="1":
			lista=['nao']
	return lista
